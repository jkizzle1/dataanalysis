# proj1_fall21
Clone it to your local computer.  

- git clone (url)

Read the instructions and grading rubric in Project 1 Instructions.pdf.  

Modify the code in proj1.py.  To add this file to the staging area for a commit use:

- git add porj1.py

Be sure to do at least 3 commits to earn up to 15 points.  To commit use:

- git commit -m "message"

To push your commits to github use:

- git push

Submit the url for your repository on github on Canvas by the due date.
