# -*- coding: utf-8 -*-
"""
Created on Sat Jul 17 16:09:52 2021

@author: ashbu
"""

# Your name: Joyce Kim 
# Your student id: 06054938
# Your email: jkizzle@umich.edu
# List who you have worked with on this project:

import io
import sys
import csv
import unittest
          

def read_csv(file):
    '''
    Function to read in a CSV

    Parameters
    ----------
    file : string
        the name of the file you're reading in

    Returns
    -------
    data_dict : dict
        the double-nested dictionary that holds the data from the csv.

    '''
    
    data_dict = {}
    row_count =  1

# write your code here that does things
    with open(file,"r") as f:  
# it should read in the lines of data
        lines = f.readlines() 
        temp = lines[0].strip('\n')
# it should also seperate the first row as header information
        header_keys = temp.split(",") 
        for j in range(1, len(lines)): 
            temp = lines[j].strip('\n')
            data = temp.split(",")
# at the same time, it should grab the first item as the state information
            state = data[0]  #key for data_dict 
            inner_dict = {}
            for i in range(1, len(data)):  
                inner_dict[header_keys[i]] = int(data[i])
            data_dict[state] = inner_dict

# the end result of the data should be formated like so
# ex: (ap_dict) {“Alabama”: {“AMERICAN INDIAN/ALASKA NATIVE”: 1, “ASIAN”: 61,...},...}
   
    # pass                            
    return data_dict


def pct_calc(data_dict):
    '''
    Function to compute demographic percentages
    Parameters
    ----------
    data_dict : dict
        the dictionary you're passing in. Should be the data dict from the 
        census or AP data. 

    Returns
    -------
    pct_dict: dict
        the dictionary that represents the data in terms of percentage share 
        for each demographic for each state in the data set.
    '''
    
    # declaring dict to hold pct vals
    pct_dict = {}

    # write in code here
    # it should take the number for each demographic for each state and divide it by the state total column
    for state in data_dict.keys():
        pct_dict[state] = {}
        for demo in data_dict[state].keys(): 
            if demo != "State Totals":
                value = data_dict[state][demo] / data_dict[state]["State Totals"]
                value = round(value * 100, 2)
                pct_dict[state][demo] = value 

    # ex: value = census_data["Alabama"]["WHITE]/census_data["Alabama]["State Totals"]
    # ex: round(value * 100, 2)          
    #pass
    return(pct_dict)


def pct_dif(data_dict1, data_dict2):
    '''
    Function to compute the difference between the demographic percentages

    Parameters
    ----------
    data_dict1 : dict
        the first data_dict you pass in. In this case, the ap_data
    data_dict2 : dict
        the second data_dict you pass in. In this case, the census_data

    Returns
    -------
    pct_dif_dict: dict
        the dictionary of the percent differences.
    '''
    # pass
    
    # creating the dictionary to hold the pct differences for each "cell"
    pct_dif_dict = {}
    
    
    # write code here
    
    for state in data_dict1.keys():
        pct_dif_dict[state] = {}
        for demo in data_dict1[state].keys(): 
            if demo != "NO RESPONSE":
                if " " in  state:
                    state2 = state.replace(" ", "-")
                else:
                    state2 = state.replace("-", " ")
                value = data_dict1[state][demo] - data_dict2[state2][demo] 
                value = abs(round(value, 2))
                pct_dif_dict[state][demo] = value 


    # it should subtract the % val of each val in the 2nd dict from the 1st dict
    # it should take the absolute value of that difference and round it to 2 decimal places
    # ex: value = ap_data["Alabama"]["WHITE] - census_data["Alabama"]["WHITE] 
    # ex: abs(round(value, 2))
    # hint: you want to have a way to deal with the difference in naming conventions
    # ex: "North Carolina" vs "North-Carolina" string.replace is your friend
    
    # pass
    return(pct_dif_dict)

def csv_out(data_dict, file_name):
    '''
    Function to write output to a file    

    Parameters
    ----------
    data_dict : dict
        the data dictionary you are writing to the file. In this case, 
        the result from pct_dif_dict
        
    file_name : str
        the name of the file you are writing.

    Returns
    -------
    None. (Doesn't return anything)
    '''
    
    with open(file_name, "w", newline="") as fileout:
        
        header = ["State"] + list(data_dict["Alabama"].keys())
        
        # you'll want to write the rest of the code here
        
        mywriter = csv.DictWriter(fileout, delimiter = ',', fieldnames=header) 
        mywriter.writeheader()
        for data in data_dict.keys():
            fileout.write(data)
            mywriter.writerow(data_dict[data])
            

        # you want to write the header info as the first row 
        # you want to then write each subsequent row of data 
        # the rows will look like this
        # ex: Alabama,0.2,18.32,21.16,2.17,0.05,3.58,1.98,1.45
    #pass
            
def max_min_mutate(data_dict, col_list):
    # Do not change the code in this function
    '''
    function to mutate the data to simplify sorting

    Parameters
    ----------
    data_dict : dict
        dictionary of data passed in. In this case, it's the 
    col_list : list
        list of columns to mutate to.

    Returns
    -------
    demo_vals: dict
        DESCRIPTION.

    '''
    # Do not change the code in this function
    demo_vals = {}
    
    for demo in col_list:
        demo_vals.setdefault(demo, {})
        
        for state in data_dict:
            demo_vals[demo].setdefault(state, data_dict[state][demo])
        
    return(demo_vals)

def max_min(data_dict):
    '''
    function to find the 5 max and min states & vals for each demographic

    Parameters
    ----------
    data_dict : dict
        the data_dictionary you're passing in. In this case, the mutated dict

    Returns
    -------
    max_min: 
        a triple nested dict with the this basic format
        {"max":{demographic:{"state":value}}}
    '''
    max_min = {"max":{},"min":{}}
    
    # fill out the code in between here
    for demo in data_dict:
        sorted_demo = sorted(data_dict[demo].items(), key=lambda x:x[1], reverse=True)
        max = sorted_demo[:5]
        min = sorted_demo[-5:]
        max_min["max"][demo] = {}
        for pair in max:
            max_min["max"][demo][pair[0]] = pair[1]
        max_min["min"][demo] = {}
        for pair in min: 
            max_min["min"][demo][pair[0]] = pair[1]

    # you'll want to make code to fill the dictionary
    # the second inner layer will look like {"max":{demographic:{}}
    # the innermost layer will look like {demographic:{"state":value}}
    
    # printing and returning the data
    #print(max_min)

    #pass
    return(max_min)

#def nat_pct(data_dict, col_list):
    '''
    EXTRA CREDIT
    function to calculate the percentages for each demographic on natl. level    

    Parameters
    ----------
    data_dict : dict
        the data dictionary you are passing in. Either AP or Census data
    col_list : list
        list of the columns to loop through. helps filter out state totals cols

    Returns
    -------
    data_dict_totals
        dictionary of the national demographic percentages

    '''
    data_dict_totals = {}
    
    # fill out code here
    # you'll want to add the demographics as the outerdict keys
    # then you'll want to cycle through the states in the data dict
    # while you're doing that, you'll be accumulating the totals for each demographic
    # you'll then convert each value to a demographic percentage
    # finally, you'll return the dictionary
    pass                                           
    return(data_dict_totals)
        
#def nat_dif(data_dict1, data_dict2):
    '''
    EXTRA CREDIT
    function to calculate the difference on the national level

    Parameters
    ----------
    data_dict1 : dict
        the first data dict you are passing in
    data_dict2 : dict
        the 2nd data dict you are passing in.

    Returns
    nat_dif: dict
        the dictionary consisting of the demographic difference on natl. level
    
    '''
    nat_dif = {}
    
    # fill out code here
    # you'll want to remove the state totals 
    # then you'll want to loop through both dicts and find the differences
    # finally, you'll want to return those differences
     
    return(nat_dif)
             
def main():
    # reading in the data
    ap_data = read_csv("ap_cleaned.csv")
    census_data = read_csv("census_cleaned.csv")
    
    # computing demographic percentages
    ap_pct = pct_calc(ap_data)
    census_pct = pct_calc(census_data)  

    # computing the difference between test taker and state demographics
    pct_dif_dict = pct_dif(ap_pct, census_pct)
    
    
    
    # outputing the csv
    csv_out(pct_dif_dict, "proj1-Kim.csv")
        
    # creating a list from the keys of inner dict
    col_list = list(pct_dif_dict["Alabama"].keys())
    
    # mutating the data
    mutated = max_min_mutate(pct_dif_dict, col_list)

    # finding the max and min vals
    max_min_vals = max_min(mutated)
        
    """# extra credit
    # providing a list of col vals to cycle through
    col_list = census_data["Alabama"].keys()
    
    # computing the national percentages
    ap_nat_pct = nat_pct(ap_data, col_list)
    census_nat_pct = nat_pct(census_data, col_list)    
    
    print(ap_nat_pct)
    print(census_nat_pct)
    
    # computing the difference between them
    dif = nat_dif(ap_nat_pct, census_nat_pct)
        
    print("Difference between AP Comp Sci A and national demographics:\n",
          dif)"""
        
main()

# unit testing
# Don't touch anything below here
class HWTest(unittest.TestCase):
    
    def setUp(self):
        # surpressing output on unit testing
        suppress_text = io.StringIO()
        sys.stdout = suppress_text 
        
        # setting up the data we'll need here
        # basically, redoing all the stuff we did in the main function
        self.ap_data = read_csv("ap_cleaned.csv")
        self.census_data = read_csv("census_cleaned.csv")
        
        self.ap_pct = pct_calc(self.ap_data)
        self.census_pct = pct_calc(self.census_data)
        
        self.pct_dif_dict = pct_dif(self.ap_pct, self.census_pct)
        
        self.col_list = list(self.pct_dif_dict["Alabama"].keys())

        self.mutated = max_min_mutate(self.pct_dif_dict, self.col_list)
        
        self.max_min_val = max_min(self.mutated)
        
        """# extra credit
        # providing a list of col vals to cycle through
        self.col_list = self.census_data["Alabama"].keys()
        
        # computing the national percentages
        self.ap_nat_pct = nat_pct(self.ap_data, self.col_list)
        self.census_nat_pct = nat_pct(self.census_data, self.col_list) 
        
        self.dif = nat_dif(self.ap_nat_pct, self.census_nat_pct)"""
        
    # testing the csv reading func is working properly
    def test_read_csv(self):
         test = read_csv("ap_cleaned.csv")
        
         self.assertEqual(test["Alabama"]["ASIAN"], 61)
         
    # testing the pct_calc function
    def test_pct_calc(self):
        self.assertEqual(pct_calc({"state":{"demo":5,"State Totals":10}}), 
                         {"state":{"demo": 50.0}})

    # second test on the pct_calc function
    # fails because my value is wrong (doh!)
    def test2_pct_calc(self):
        self.assertEqual(
            self.ap_pct["Alabama"]["ASIAN"], 
            19.68)

    # testing the pct_dif function
    def test_pct_dif(self):
        self.assertEqual(
            pct_dif({"state":{"demo":50.0}},{"state":{"demo":50.0}}),
            {'state': {'demo': 0.0}}           
            )
        
    # second test on the pct_dif function
    # needs a valid value though brah
    def test2_pct_dif(self):
        self.assertEqual(
            self.pct_dif_dict["Alabama"]["AMERICAN INDIAN/ALASKA NATIVE"],
            0.2)
    
    # testing the max_min function
    def test_max_min(self):
        self.assertEqual(
            max_min({"demo":{"a":1,"b":2,"c":3,"d":4,"e":5}})
            ,
            {'max': {'demo': {'e': 5, 'd': 4, 'c': 3, 'b': 2, 'a': 1}},
             'min': {'demo': {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}}}
            )
        
    # second test on the max_min function
    def test2_max_min(self):
        self.assertEqual(
            self.max_min_val["max"]["BLACK"]["District-of-Columbia"],
            23.92)
    
    """# testing the nat_pct extra credit function
    def test_nat_pct(self):
       self.assertEqual(
       nat_pct({"state":{"demo":5,"State Totals":10}},["demo", "State Totals"]),
       {"demo":50.0, "State Totals":10})
        
    # second test for the nat_pct extra credit function
    def test2_nat_pct(self):
        self.assertEqual(
            self.ap_nat_pct["AMERICAN INDIAN/ALASKA NATIVE"], 
            0.29)
    
    # testing the nat_dif extra credit function
    def test_nat_dif(self):
        self.assertEqual(
            nat_dif({"demo":0.53, "State Totals": 1},{"demo":0.5, "State Totals": 1}),
            {"demo":0.03}
            )
     
    # second test for the nat_dif extra credit function
    def test2_nat_dif(self):
        self.assertEqual(
            self.dif["ASIAN"],
            27.93)"""

if __name__ == '__main__':
    unittest.main(verbosity=2)






        

